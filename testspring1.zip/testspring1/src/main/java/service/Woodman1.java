package service;

import dao.Axe;

public class Woodman1 {
    private String name;
    private Axe axe;

    public void setName(String name) {
        this.name = name;
    }

    public void setAxe(Axe axe) {
        this.axe = axe;
    }

    public void cutWood(){
        System.out.println("Woodcutter '"+name+"' said:'"+ axe.chop() +"'");
    }
}
