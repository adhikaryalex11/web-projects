package service;

import dao.Axe;

public class Woodman2 {
    private String name;
    private Axe axe;


    public Woodman2(String name, Axe axe) {
        this.name = name;
        this.axe = axe;
    }

    public void cutWood(){
        System.out.println("Woodcutter '" +name+"' said :'" +axe.chop() +"'");
    }
}