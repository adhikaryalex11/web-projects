package dao;

public interface Axe {
    public String chop();

}
