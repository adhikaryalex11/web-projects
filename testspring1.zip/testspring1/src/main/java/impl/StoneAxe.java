package impl;

import dao.Axe;

public class StoneAxe implements Axe {

    public StoneAxe() {
        System.out.println("The Copper Axe is created");
    }

    @Override
    public String chop(){
        return "Copper axe can cut big and small trees";
    }
}


