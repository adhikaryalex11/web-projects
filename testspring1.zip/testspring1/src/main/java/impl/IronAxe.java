package impl;

import dao.Axe;

public class IronAxe implements Axe {
    public IronAxe() {
        System.out.println("The Iron Axe is created");
    }

    @Override
    public String chop(){
        return "Iron axe can be used to split mountains and stones";
    }
}
