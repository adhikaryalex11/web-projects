package impl;

import dao.Axe;

public class CopperAxe implements Axe {

    public CopperAxe() {
        System.out.println("The copper axe is created");
    }

    @Override
    public String chop() {
        return "Copper Axe can cut big and small trees";
    }
}