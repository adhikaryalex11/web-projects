package common;

import dao.Axe;
import impl.CopperAxe;
import impl.IronAxe;
import impl.StoneAxe;
import javafx.application.Application;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import service.Woodman1;
import service.Woodman2;

public class SpringBeansGetTest {
    ApplicationContext context = null;

    @Before
    public void init(){
        System.out.println("start spring container");
        context = new ClassPathXmlApplicationContext("applicationContext.xml");
    }

    @Test
    public void  testGetBeans(){
        Axe axe = new StoneAxe();
        System.out.println(axe.chop());
    }
    @Test
    public void  testGetBeans2(){
        Axe axe1 = (StoneAxe)context.getBean("stoneAxe");
        System.out.println(axe1.chop());
        Axe axe2 = (CopperAxe)context.getBean("copperAxe");
        System.out.println(axe2.chop());
        Axe axe3 = (IronAxe)context.getBean("ironAxe");
        System.out.println(axe3.chop());

    }
    @Test
    public void testWoodman1(){
        Woodman1 man1 = (Woodman1) context.getBean("woodman1");
        man1.cutWood();
    }

    @Test
    public void testWoodman2(){
        Woodman2 man2 = (Woodman2) context.getBean("woodman2");
        man2.cutWood();
    }

}