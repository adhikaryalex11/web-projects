import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    books: [
      {
        check: false,
        name: "book1",
        isbn: "12345678",
        author: {
          name: "sandy",
          country: "sri lanka",
          birthday: "2000-01-15",
          web: "www.sandy.com",
        },
        published: "2020-5-4",
        language: "English",
      },
      {
        check: false,
        name: "sinhala",
        isbn: "34543543543",

        author: {
          name: "mr.robot",
          country: "sri lanka",
          birthday: "2000-01-15",
          web: "www.robot.com",
        },
        published: "2020-5-4",
        language: "English",
      },
      {
        check: false,

        name: "3001",
        isbn: "12345678",

        author: {
          name: "a.c.clack",
          country: "sri lanka",
          birthday: "2000-01-15",
          web: "www.acc.com",
        },
        published: "2020-5-4",
        language: "English",
      },
      {
        check: false,

        name: "book4",
        isbn: "12345678",

        author: {
          name: "sandy",
          country: "sri lanka",
          birthday: "2000-01-15",
          web: "www.sandy.com",
        },
        published: "2020-5-4",
        language: "English",
      },
      {
        check: false,
        name: "book5",
        isbn: "12345678",

        author: {
          name: "sandy",
          country: "sri lanka",
          birthday: "2000-01-15",
          web: "www.sandy.com",
        },
        published: "2020-5-4",
        language: "English",
      },
    ],
  },
  getters: {},
  mutations: {
    deleteSelected(state){
      state.books = state.books.filter(b => b.check == false);
    }
  },
  actions: {},
  modules: {},
})
