<template>
  <div class="home">
    <div class="container">
      <div class="row">
        <h4 class="title">New Book</h4>
        <hr>
        <div class="row">
          <div class="col-6">
            <div class="form-group">
              <input type="text" id="title" placeholder="Book..." v-model="q">
            </div>
          </div>
          <div class="col-3 p-0-10">
            <button class="btn w-100" @click="search">Search</button>
          </div>
          <div class="col-3 p-0-10">
            <button class="btn w-100 " @click="deleteChecked">Delete Checked Answer</button>
          </div>
        </div>


        <!-- table  -->
        <div class="row">

          <div class="col-12">
            <div>
              <table class="bookTable w-100">
                <tr>
                  <th></th>
                  <th>Book Name</th>
                  <th>ISBN</th>
                  <th></th>
                </tr>
                <tr v-for="b, index in rows" :key="index" :class="(index % 2) == 1 ? 'orow' : 'erow'">
                  <td class="txtcenter">
                    <input type="checkbox" v-model="b.check">
                  </td>
                  <td>
                    {{ b.name }}
                  </td>
                  <td> <span>{{ b.isbn }}</span> </td>
                  <td class="txtcenter"><a class="link" @click="showBookInfo(index)">View Details</a></td>

                </tr>
              </table>
            </div>
          </div>
        </div>


        <!-- book data -->

        <div class="row" v-if="rows[currentBookId]">
          <h4 class="title">Book Information</h4>
          <hr>
          <div class="col-12">
            <div class="row infoCard">
              <div class="col-4">
                <img class="image" src="@/assets/img/books/book.jpg" alt="">
              </div>
              <div class="col-8">
                <table class="w-100">
                  <tr>
                    <td class="orow">Name : <span class="red">{{ rows[currentBookId].name }}</span></td>
                  </tr>
                  <tr>
                    <td class="erow">ISBN : {{ rows[currentBookId].isbn }}</td>
                  </tr>
                  <tr>
                    <td class="orow">Author : <a class="link" @click="showAuthorInfo(currentBookId)">{{
                        rows[currentBookId].author.name
                    }}</a></td>
                  </tr>
                  <tr>
                    <td class="erow">Published : {{ rows[currentBookId].published }}</td>
                  </tr>
                  <tr>
                    <td class="orow">Language : {{ rows[currentBookId].language }}</td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
        </div>

        <!-- author info  -->

        <div class="row" v-if="rows[currentAuthorId]">
          <h4 class="title">Author Information</h4>
          <hr>
          <div class="col-12">
            <div class="row infoCard">
              <div class="col-4">
                <img class="image" src="@/assets/img/authors/auth.jpg" alt="">
              </div>
              <div class="col-8">
                <table class="w-100">
                  <tr>
                    <td class="orow">Author Name : <span class="red">{{ rows[currentBookId].author.name }}</span></td>
                  </tr>
                  <tr>
                    <td class="erow">Country : {{ rows[currentBookId].author.country }}</td>
                  </tr>
                  <tr>
                    <td class="orow">Birthday : {{ rows[currentBookId].author.birthday }}</td>
                  </tr>
                  <tr>
                    <td class="erow">Website : {{ rows[currentBookId].author.web }}</td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
        </div>



      </div>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src


export default {
  name: 'HomeView',
  data() {
    return {
      currentBookId: null,
      currentAuthorId: null,
      rows: [],
      tempRows: [],
      q:""
    }
  },
  mounted() {
    this.rows = this.$store.state.books
    this.tempRows = this.$store.state.books
    // console.log(this.rows[this.currentBookId].name)
  },
  methods: {
    search() {
      this.rows = this.tempRows.filter(row => row.name.includes(this.q))
    },
    showBookInfo(index) {
      this.currentBookId = index
    },
    showAuthorInfo(index) {
      this.currentAuthorId = index
    },
    deleteChecked() {
      if (confirm("Are you sure you want to delete?")) {
        this.$store.commit("deleteSelected")
      }
      this.rows = this.$store.state.books
      this.tempRows = this.$store.state.books
    }
  }
}
</script>

<style>
.btn {
  margin-top: 17px;
  padding: 15px;
}

table th {
  background-color: #000;
  padding: 10px 10px;
  color: #fff;
  font-weight: bold;
}

.orow {
  background-color: rgb(184, 181, 181);
  color: #000;
  padding: 10px 10px;
  /* font-weight: bold; */
  font-size: 16px;


}

.erow {
  background-color: rgb(233, 229, 229);
  color: #000;
  padding: 10px 10px;
  /* font-weight: bold; */
  font-size: 16px;
}

.red {
  color: #f00;
}

.bookTable {
  padding: 20px 50px
}

.txtcenter {
  vertical-align: middle;
  text-align: center;
}

.image {
  width: 200px;
}

.link {
  cursor: pointer;
  text-decoration: underline
}

.infoCard {
  padding: 20px 350px
}
</style>
