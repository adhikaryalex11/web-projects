var photos = ["./images/1.jpg", "./images/2.jpg", "./images/3.jpg", "./images/4.jpg",
    "./images/5.jpg", "./images/6.jpg", "./images/7.png", "./images/9.JPG", "./images/10.jpg",
    "./images/12.jpg", "./images/13.gif", "./images/14.jpg", "./images/15.jpg", "./images/16.jpg",
]



var imgTag = document.querySelector("img");

var count = 0;

function next() {
    count++;
    if (count >= photos.length) {
        count = 0;
        imgTag.src = photos[count];

    } else {
        imgTag.src = photos[count];
    }
};

function prep() {
    count--;
    if (count < 0) {
        count = photos.length - 1;
        imgTag.src = photos[count];

    } else {
        imgTag.src = photos[count];
    }
};
setInterval(next, 2000);
var nextBtt = document.querySelector('button')


document.onkeydown = checkKey;

function checkKey(e) {

    e = e || window.event;

    if (e.keyCode == '37') {
        prep() //left arrow
    } else if (e.keyCode == '39') {
        next() // right arrow
    }

}