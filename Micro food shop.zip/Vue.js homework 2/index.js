function addToCart(product) {
    //alert(product)
    if ($("#Chocolate").val() < 0) {
        $("#Chocolate").val(0);


    } else {
        console.log(product);

        var t = $('#table1').DataTable();
        var quantity = document.getElementById(product).innerText;
        switch (product) {
            case "Chocolate":
                t.row.add(["Chocolate", quantity, "50", quantity * 1000, "<i style='cursor:pointer' class='btnDelete fas fa-trash-alt'></i>"]).draw();
                //t.row.add([{"Product":"Crayons","Quantity":quantity,"Price":"100","Amount":quantity*100,"":"<i style='cursor:pointer' class='btnDelete fas fa-trash-alt'></i>"}]).draw();
                calculateTotalAmount();

                break;
            case "Cheddar":
                t.row.add(["Cheddar", quantity, "35", quantity * 1000, "<i style='cursor:pointer' class='btnDelete fas fa-trash-alt'></i>"]).draw();
                calculateTotalAmount()
                break;
            case "Potato":
                t.row.add(["Potato", quantity, "2", quantity * 750, "<i style='cursor:pointer' class='btnDelete fas fa-trash-alt'></i>"]).draw();
                calculateTotalAmount()
                break;
            case "Dew":
                t.row.add(["Dew", quantity, "5", quantity * 250, "<i style='cursor:pointer' class='btnDelete fas fa-trash-alt'></i>"]).draw();
                calculateTotalAmount()
                break;
            default:
                break;
        }

    }

}


function increment(product) {
    x = document.getElementById(product).innerText;



    document.getElementById(product).innerHTML = ++x;
}

function decrement(product) {
    x = document.getElementById(product).innerText;
    if (x > 0) {

        document.getElementById(product).innerHTML = --x;
    }

}

$("#table1").on('click', '.btnDelete', function() {
    var table = $('#table1').DataTable();
    table.row($(this).closest('tr')).remove().draw();
    calculateTotalAmount();
});

$("#print").click(function() {
    var table = $('#table1').DataTable();
    table.clear().draw();
    alert('Reached')
});

function calculateTotalAmount() {
    var table = $('#table1').DataTable();
    var data = table.rows().data();
    var amount = 0;
    data.each(function(value, index) {
        console.log(`For index ${index}, data value is ${value[3]}`);
        amount = amount + value[3];
    });
    document.getElementById("total").innerHTML = "Total amount: &#x20b9;" + amount

}

function myFunction() {
    const resetButton = document.createElement('button');
    resetButton.setAttribute('class', 'reset');
    resetButton.innerHTML = 'Reset';
    console.log(document.getElementsByClassName("dt-buttons")[0])
    document.getElementsByClassName("dt-buttons")[0].appendChild(resetButton);
}

function resetTable() {
    //alert('Here')
    var table = $('#table1').DataTable();
    table.rows().remove().draw();
}