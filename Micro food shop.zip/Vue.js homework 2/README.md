# Shopping-Cart
A simple shopping cart using HTML, CSS, Javascript and Jquery (DataTable)

A simple shopping cart which has 4 products with its price mentioned. Quantity can be choosed accordingly.
DataTable is used to display the products chosen along with the total amount.

Products can be removed/updated as required.

The final bill can be printed using DataTable export pdf option.
After printing, table can be cleared using reset button.
